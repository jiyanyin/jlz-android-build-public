package com.jiyanyin.floattimer;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.provider.Settings;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class TimerStore {
    private static final String PREF = "timer_store";
    private final Context context;
    private final SharedPreferences p;

    private static final String F_BASE = "focus_base";
    private static final String F_START = "focus_start";
    private static final String F_RUN = "focus_run";
    private static final String F_BOOT = "focus_boot";

    private static final String Q_BASE = "question_base";
    private static final String Q_START = "question_start";
    private static final String Q_RUN = "question_run";
    private static final String Q_BOOT = "question_boot";

    private static final String DAY = "day";
    private static final String RECORDS = "records";

    public TimerStore(Context context) {
        this.context = context.getApplicationContext();
        this.p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        ensureToday();
    }

    private int bootCount() {
        try {
            return Settings.Global.getInt(context.getContentResolver(), Settings.Global.BOOT_COUNT);
        } catch (Exception e) {
            return -1;
        }
    }

    public synchronized void ensureToday() {
        String today = LocalDate.now().toString();
        String saved = p.getString(DAY, "");
        if (!today.equals(saved)) {
            SharedPreferences.Editor e = p.edit();
            e.putString(DAY, today);
            e.putLong(F_BASE, 0L);
            e.putBoolean(F_RUN, false);
            e.putLong(Q_BASE, 0L);
            e.putBoolean(Q_RUN, false);
            e.putString(RECORDS, "[]");
            e.apply();
        }
    }

    private long elapsed(String baseKey, String startKey, String runKey, String bootKey) {
        ensureToday();
        long base = p.getLong(baseKey, 0L);
        if (!p.getBoolean(runKey, false)) return base;
        if (p.getInt(bootKey, -2) != bootCount()) return base;
        return Math.max(0L, base + (SystemClock.elapsedRealtime() - p.getLong(startKey, SystemClock.elapsedRealtime())));
    }

    public synchronized long focusElapsed() { return elapsed(F_BASE, F_START, F_RUN, F_BOOT); }
    public synchronized long questionElapsed() { return elapsed(Q_BASE, Q_START, Q_RUN, Q_BOOT); }
    public synchronized boolean isFocusRunning() { ensureToday(); return p.getBoolean(F_RUN, false); }
    public synchronized boolean isQuestionRunning() { ensureToday(); return p.getBoolean(Q_RUN, false); }

    public synchronized void startFocus() {
        ensureToday();
        if (isFocusRunning()) return;
        p.edit().putBoolean(F_RUN, true)
                .putLong(F_START, SystemClock.elapsedRealtime())
                .putInt(F_BOOT, bootCount()).apply();
    }

    public synchronized void pauseFocus() {
        if (!isFocusRunning()) return;
        long now = focusElapsed();
        p.edit().putLong(F_BASE, now).putBoolean(F_RUN, false).apply();
    }

    public synchronized void startQuestion() {
        ensureToday();
        if (isQuestionRunning()) return;
        p.edit().putBoolean(Q_RUN, true)
                .putLong(Q_START, SystemClock.elapsedRealtime())
                .putInt(Q_BOOT, bootCount()).apply();
    }

    public synchronized void pauseQuestion() {
        if (!isQuestionRunning()) return;
        long now = questionElapsed();
        p.edit().putLong(Q_BASE, now).putBoolean(Q_RUN, false).apply();
    }

    public synchronized void checkpoint() {
        if (isFocusRunning()) {
            long f = focusElapsed();
            p.edit().putLong(F_BASE, f)
                    .putLong(F_START, SystemClock.elapsedRealtime())
                    .putInt(F_BOOT, bootCount()).apply();
        }
        if (isQuestionRunning()) {
            long q = questionElapsed();
            p.edit().putLong(Q_BASE, q)
                    .putLong(Q_START, SystemClock.elapsedRealtime())
                    .putInt(Q_BOOT, bootCount()).apply();
        }
    }

    public synchronized long finishQuestionAndStartNext() {
        ensureToday();
        long ms = questionElapsed();
        if (ms > 0) appendRecord(ms);
        p.edit().putLong(Q_BASE, 0L)
                .putBoolean(Q_RUN, true)
                .putLong(Q_START, SystemClock.elapsedRealtime())
                .putInt(Q_BOOT, bootCount()).apply();
        return ms;
    }

    private void appendRecord(long ms) {
        JSONArray arr;
        try { arr = new JSONArray(p.getString(RECORDS, "[]")); }
        catch (JSONException e) { arr = new JSONArray(); }
        JSONObject o = new JSONObject();
        try {
            o.put("durationMs", ms);
            o.put("finishedAt", System.currentTimeMillis());
            arr.put(o);
            p.edit().putString(RECORDS, arr.toString()).apply();
        } catch (JSONException ignored) { }
    }

    public synchronized List<Long> records() {
        ensureToday();
        List<Long> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(p.getString(RECORDS, "[]"));
            for (int i = 0; i < arr.length(); i++) out.add(arr.getJSONObject(i).optLong("durationMs", 0L));
        } catch (JSONException ignored) { }
        return out;
    }

    public synchronized void resetToday() {
        String today = LocalDate.now().toString();
        p.edit().putString(DAY, today)
                .putLong(F_BASE, 0L).putBoolean(F_RUN, false)
                .putLong(Q_BASE, 0L).putBoolean(Q_RUN, false)
                .putString(RECORDS, "[]").apply();
    }
}
