package com.jiyanyin.floattimer;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class FloatingTimerService extends Service {
    public static final String ACTION_STOP = "com.jiyanyin.floattimer.STOP";
    private static final String CHANNEL = "float_timer";
    private static final int NOTI_ID = 2109;

    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private View overlay;
    private TextView clockText, focusText, questionText;
    private TextView focusBtn, questionBtn, doneBtn;
    private TimerStore store;
    private final Handler h = new Handler(Looper.getMainLooper());
    private int tickCount = 0;

    @Override public void onCreate() {
        super.onCreate();
        store = new TimerStore(this);
        createChannel();
        startForeground(NOTI_ID, buildNotification());
        if (Settings.canDrawOverlays(this)) showOverlay();
        h.post(ticker);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (overlay == null && Settings.canDrawOverlays(this)) showOverlay();
        return START_STICKY;
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(this, FloatingTimerService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("悬浮计时正在运行")
                .setContentText("专注与单题计时会持续保留")
                .setContentIntent(pi)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "关闭", stopPi).build())
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "悬浮计时", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("保持悬浮计时器稳定运行");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private TextView tv(String text, float sp, boolean mono) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.rgb(18,18,18));
        t.setTextSize(sp);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (mono) t.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        t.setSingleLine(true);
        return t;
    }

    private GradientDrawable bg(int alpha, float radius, int strokeAlpha) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.argb(alpha,255,255,255));
        g.setCornerRadius(dp(radius));
        g.setStroke(dp(0.7f), Color.argb(strokeAlpha,0,0,0));
        return g;
    }

    private TextView miniButton(String s) {
        TextView b = tv(s, 10.5f, false);
        b.setGravity(Gravity.CENTER);
        b.setMinWidth(dp(23));
        b.setMinHeight(dp(22));
        b.setPadding(dp(4),0,dp(4),0);
        b.setBackground(bg(22, 10, 10));
        return b;
    }

    private void showOverlay() {
        if (overlay != null) return;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(8), dp(4), dp(6), dp(5));
        card.setBackground(bg(232, 14, 26));
        card.setElevation(dp(1));

        // Row 1: clock. This row is also the drag handle.
        LinearLayout r1 = row();
        clockText = tv("00:00:00", 10.5f, true);
        clockText.setTextColor(Color.rgb(35,35,35));
        r1.addView(clockText, new LinearLayout.LayoutParams(0, dp(18), 1f));
        TextView dragHint = tv("⋮⋮", 9f, false);
        dragHint.setTextColor(Color.argb(90,0,0,0));
        r1.addView(dragHint, new LinearLayout.LayoutParams(dp(24), dp(18)));
        card.addView(r1);

        LinearLayout r2 = row();
        focusText = tv("专注 00:00:00", 10.5f, true);
        r2.addView(focusText, new LinearLayout.LayoutParams(0, dp(23), 1f));
        focusBtn = miniButton("Ⅱ");
        r2.addView(focusBtn, new LinearLayout.LayoutParams(dp(27), dp(22)));
        card.addView(r2);

        LinearLayout r3 = row();
        questionText = tv("单题 00:00:00", 10.5f, true);
        r3.addView(questionText, new LinearLayout.LayoutParams(0, dp(23), 1f));
        questionBtn = miniButton("▶");
        r3.addView(questionBtn, new LinearLayout.LayoutParams(dp(27), dp(22)));
        Space gap = new Space(this);
        r3.addView(gap, new LinearLayout.LayoutParams(dp(3), 1));
        doneBtn = miniButton("✓");
        r3.addView(doneBtn, new LinearLayout.LayoutParams(dp(27), dp(22)));
        card.addView(r3);

        lp = new WindowManager.LayoutParams(
                dp(205), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                android.graphics.PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        int sw = getResources().getDisplayMetrics().widthPixels;
        SharedPreferences pos = getSharedPreferences("position", MODE_PRIVATE);
        lp.x = pos.getInt("x", Math.max(0, (sw - dp(205)) / 2));
        lp.y = pos.getInt("y", dp(27));

        overlay = card;
        wm.addView(overlay, lp);

        focusBtn.setOnClickListener(v -> {
            if (store.isFocusRunning()) store.pauseFocus(); else store.startFocus();
            updateUi();
        });
        questionBtn.setOnClickListener(v -> {
            if (store.isQuestionRunning()) store.pauseQuestion(); else store.startQuestion();
            updateUi();
        });
        doneBtn.setOnClickListener(v -> {
            long ms = store.finishQuestionAndStartNext();
            if (ms > 0) {
                if (Build.VERSION.SDK_INT >= 26) v.performHapticFeedback(HapticFeedbackConstants.CONFIRM);
                else v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            }
            updateUi();
        });

        View.OnTouchListener drag = new View.OnTouchListener() {
            int startX, startY; float downX, downY;
            @Override public boolean onTouch(View v, android.view.MotionEvent e) {
                switch (e.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        startX = lp.x; startY = lp.y; downX = e.getRawX(); downY = e.getRawY(); return true;
                    case android.view.MotionEvent.ACTION_MOVE:
                        lp.x = startX + Math.round(e.getRawX() - downX);
                        lp.y = Math.max(0, startY + Math.round(e.getRawY() - downY));
                        wm.updateViewLayout(overlay, lp); return true;
                    case android.view.MotionEvent.ACTION_UP:
                        getSharedPreferences("position", MODE_PRIVATE).edit().putInt("x", lp.x).putInt("y", lp.y).apply();
                        return true;
                }
                return false;
            }
        };
        r1.setOnTouchListener(drag);

        // Daily focus begins when the floating timer is first opened.
        if (!store.isFocusRunning() && store.focusElapsed() == 0L) store.startFocus();
        updateUi();
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            store.ensureToday();
            updateUi();
            tickCount++;
            if (tickCount % 5 == 0) store.checkpoint();
            long delay = 1000L - (System.currentTimeMillis() % 1000L) + 10L;
            h.postDelayed(this, delay);
        }
    };

    private void updateUi() {
        if (clockText == null) return;
        clockText.setText(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
        focusText.setText("专注 " + fmt(store.focusElapsed()));
        questionText.setText("单题 " + fmt(store.questionElapsed()));
        focusBtn.setText(store.isFocusRunning() ? "Ⅱ" : "▶");
        questionBtn.setText(store.isQuestionRunning() ? "Ⅱ" : "▶");
    }

    private String fmt(long ms) {
        long total = Math.max(0, ms / 1000);
        long h = total / 3600, m = (total % 3600) / 60, s = total % 60;
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, s);
    }

    @Override public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        if (store != null) store.checkpoint();
        if (wm != null && overlay != null) {
            try { wm.removeView(overlay); } catch (Exception ignored) { }
        }
        overlay = null;
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
