package com.jiyanyin.floattimer;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;

import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private TimerStore store;
    private LinearLayout history;
    private TextView summary;

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 23) getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        store = new TimerStore(this);
        setContentView(buildUi());
        requestNotificationIfNeeded();
    }

    private android.view.View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.WHITE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(26), dp(22), dp(30));
        scroll.addView(root);

        TextView title = text("悬浮计时", 28, true);
        root.addView(title);
        TextView sub = text("极简 · 透明白 · 黑字", 13, false);
        sub.setTextColor(Color.rgb(115,115,115));
        root.addView(sub);

        Space s1 = new Space(this); root.addView(s1, new LinearLayout.LayoutParams(1, dp(22)));

        Button permission = button("① 开启悬浮权限");
        permission.setOnClickListener(v -> openOverlayPermission());
        root.addView(permission, new LinearLayout.LayoutParams(-1, dp(48)));

        Space sp = new Space(this); root.addView(sp, new LinearLayout.LayoutParams(1, dp(10)));
        Button show = button("② 显示顶部计时条");
        show.setOnClickListener(v -> startOverlay());
        root.addView(show, new LinearLayout.LayoutParams(-1, dp(48)));

        Space s2 = new Space(this); root.addView(s2, new LinearLayout.LayoutParams(1, dp(28)));
        summary = text("", 15, true);
        root.addView(summary);

        Space s3 = new Space(this); root.addView(s3, new LinearLayout.LayoutParams(1, dp(14)));
        TextView histTitle = text("今日单题记录", 17, true);
        root.addView(histTitle);
        history = new LinearLayout(this);
        history.setOrientation(LinearLayout.VERTICAL);
        history.setPadding(0, dp(10), 0, 0);
        root.addView(history);

        Space s4 = new Space(this); root.addView(s4, new LinearLayout.LayoutParams(1, dp(24)));
        Button reset = button("重置今日数据");
        reset.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
                .setTitle("重置今天？")
                .setMessage("会清空今日专注时长和单题记录。")
                .setNegativeButton("取消", null)
                .setPositiveButton("重置", (d,w) -> { store.resetToday(); refresh(); })
                .show());
        root.addView(reset, new LinearLayout.LayoutParams(-1, dp(46)));
        return scroll;
    }

    private TextView text(String s, float sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(18,18,18));
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(14); b.setTextColor(Color.BLACK); b.setAllCaps(false);
        b.setBackgroundColor(Color.rgb(246,246,246));
        return b;
    }

    private void openOverlayPermission() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } else startOverlay();
    }

    private void startOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { openOverlayPermission(); return; }
        Intent i = new Intent(this, FloatingTimerService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    private void requestNotificationIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private void refresh() {
        if (summary == null || history == null) return;
        List<Long> list = store.records();
        long sum = 0; for (long x : list) sum += x;
        long avg = list.isEmpty() ? 0 : sum / list.size();
        summary.setText("今日专注  " + fmt(store.focusElapsed()) + "\n已完成 " + list.size() + " 题 · 平均 " + shortFmt(avg));
        history.removeAllViews();
        if (list.isEmpty()) {
            TextView empty = text("还没有记录。点悬浮条里的 ✓ 就会存下一题。", 13, false);
            empty.setTextColor(Color.rgb(135,135,135));
            history.addView(empty);
        } else {
            for (int i = 0; i < list.size(); i++) {
                TextView line = text(String.format(Locale.CHINA, "%02d     %s", i + 1, shortFmt(list.get(i))), 15, false);
                line.setPadding(0, dp(8), 0, dp(8));
                history.addView(line);
            }
        }
    }

    private String fmt(long ms) {
        long total = Math.max(0, ms / 1000), h = total / 3600, m = total % 3600 / 60, s = total % 60;
        return String.format(Locale.US, "%02d:%02d:%02d", h,m,s);
    }
    private String shortFmt(long ms) {
        long total = Math.max(0, ms / 1000), m = total / 60, s = total % 60;
        return m > 0 ? String.format(Locale.CHINA, "%d分%02d秒", m,s) : String.format(Locale.CHINA, "%d秒", s);
    }
}
